function NavBar() {
  return (
    <nav className="navbar">
      영화 추천 앱
    </nav>
  );
}

export default NavBar;

